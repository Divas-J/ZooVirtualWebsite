package com.zoovirtual.aplicativo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicativoApplicationTests {

	@Test
	void contextLoads() {
	}

}
