package com.zoovirtual.aplicativo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zoovirtual.aplicativo.entities.Comentario;
import com.zoovirtual.aplicativo.repository.ComentarioRepository;

@RestController
@RequestMapping(value = "/comentario")
public class ComentarioController {
	
	@Autowired
	private ComentarioRepository tb_comentario;
	
	@GetMapping
	public List<Comentario> findAll(){
		List<Comentario> listaComentario = tb_comentario.findAll();
		return listaComentario;
	}
	
	@GetMapping(value="/{id}")
	public Comentario findById(@PathVariable Long id) {
		return tb_comentario.findById(id).get();	
	}
	
	@PostMapping
	public Comentario insert(@RequestBody Comentario obj) {
	return obj = tb_comentario.save(obj);
	}
	   
	 @DeleteMapping(value = "/{id}")
	 public void delete(@PathVariable Long id) {
	 tb_comentario.deleteById(id);
	 }

}
